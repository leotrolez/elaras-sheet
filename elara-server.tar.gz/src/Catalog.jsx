import React, { useState } from 'react';
import catalog from './catalog.json';
import { normalize } from './Book.jsx';

export default function Catalog({ character, onAdd, onOpenPage }) {
  const [query, setQuery] = useState('');
  const [kind, setKind] = useState('advantages');
  const [category, setCategory] = useState('');
  const [severity, setSeverity] = useState('');
  const categories = [...new Set(catalog.filter(e => e.kind === kind).map(e => e.category))];
  const entries = catalog.filter(e => e.kind === kind && (!category || e.category === category) && (!severity || e.severities.includes(severity)) && normalize(`${e.name} ${e.requirements} ${e.description}`).includes(normalize(query)));
  return <section className="catalog">
    <h3>Escolher no livro</h3>
    <p className="muted">Leia os efeitos e requisitos antes de adicionar. Os pontos seguem as regras da mesa. Efeitos sobre atributos, perícias e defesas devem ser registrados nos ajustes da ficha.</p>
    <div className="catalog-filters"><label className="field"><span>Tipo</span><select value={kind} onChange={e => {setKind(e.target.value);setCategory('');setSeverity('');}}><option value="advantages">Vantagens</option><option value="hindrances">Desvantagens / Complicações</option></select></label>
      <label className="field"><span>Buscar por nome, requisito ou efeito</span><input type="search" value={query} onChange={e => setQuery(e.target.value)} placeholder="Carismático, arco, Espírito…" /></label>
      <label className="field"><span>{kind === 'advantages' ? 'Categoria' : 'Impacto'}</span>{kind === 'advantages' ? <select value={category} onChange={e => setCategory(e.target.value)}><option value="">Todas</option>{categories.map(x => <option key={x}>{x}</option>)}</select> : <select value={severity} onChange={e => setSeverity(e.target.value)}><option value="">Todos</option><option>Menor</option><option>Maior</option></select>}</label>
    </div>
    <p className="muted">{entries.length} opções • {catalog.filter(e => e.kind === kind).length} no catálogo</p>
    <div className="catalog-results">{entries.map(entry => {
      const added = character[kind].some(x => normalize(x.name) === normalize(entry.name));
      const add = impact => onAdd(kind, {name:entry.name, description:[entry.requirements && `Requisitos: ${entry.requirements}`,entry.description,`Fonte: livro, página ${entry.page} do PDF.`].filter(Boolean).join('\n\n'), ...(kind === 'advantages' ? {power:false} : {severity:impact})});
      return <details className="catalog-entry" key={entry.id}><summary><b>{entry.name}</b><span>{kind === 'advantages' ? entry.category : entry.severities.join(' / ')}{added ? ' · Na ficha' : ''}</span></summary>
        {entry.requirements && <p><strong>Requisitos:</strong> {entry.requirements}</p>}
        <div className="catalog-description">{entry.description.split('\n\n').map((p,i) => <p key={i}>{p}</p>)}</div>
        <div className="catalog-actions"><button className="text-button" onClick={() => onOpenPage(entry.page)}>Ver página {entry.page} do PDF ↗</button>
          {kind === 'advantages' ? <button className="primary" disabled={added} onClick={() => add() }>{added ? 'Já adicionada' : 'Adicionar à ficha'}</button> : entry.severities.map(s => <button key={s} className="primary" disabled={added} onClick={() => add(s)}>Adicionar {s.toLowerCase()} (+{s === 'Maior' ? 5 : 3})</button>)}
        </div>
      </details>;
    })}{!entries.length && <p>Nenhuma opção encontrada. Tente outro termo ou limpe os filtros.</p>}</div>
  </section>;
}
